import React from 'react'

const Footer = () => {
  return (
    <div className={`flex bg-btnColor w-full p-10 justify-center items-center text-white`}>
        @moiz.dev 2024{" "}
      </div>
  )
}

export default Footer
