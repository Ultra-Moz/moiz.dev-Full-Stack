import React from 'react'

const AdminContacts = () => {
  return (
    <div>
      Admin Contacts
    </div>
  )
}

export default AdminContacts
